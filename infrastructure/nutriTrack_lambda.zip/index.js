const serverless = require("serverless-http");
const express = require("express");
const cors = require("cors");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand, ScanCommand } = require("@aws-sdk/lib-dynamodb");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { v4: uuidv4 } = require("uuid");
const { GoogleGenerativeAI } = require("@google/generative-ai");

const app = express();
app.use(cors());
app.use(express.json());

// Khởi tạo các AWS Client (Chạy trên Lambda tự động có quyền IAM từ Role)
const ddbClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(ddbClient);
const s3Client = new S3Client({});
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

const FOODS_TABLE = process.env.FOODS_TABLE;
const IMAGES_BUCKET = "nutritrack-images";

// 1. API: Lấy URL để Mobile Upload Ảnh trực tiếp lên S3 (Pre-signed URL)
app.get("/api/upload-url", async (req, res) => {
    try {
        const filename = `food-images/${uuidv4()}-${Date.now()}.jpg`;
        const command = new PutObjectCommand({
            Bucket: IMAGES_BUCKET,
            Key: filename,
            ContentType: "image/jpeg",
        });

        // Tạo URL có hiệu lực trong 1 giờ
        const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });

        // URL công khai để Mobile app có thể lưu vào DB và hiển thị sau này
        const publicUrl = `https://${IMAGES_BUCKET}.s3.amazonaws.com/${filename}`;

        res.json({ uploadUrl, publicUrl, filename });
    } catch (err) {
        console.error("Lỗi S3 Presigner:", err);
        res.status(500).json({ error: "Could not generate upload URL" });
    }
});

// 2. API: Lưu nhật ký món ăn (Diary) vào DynamoDB
app.post("/api/foods", async (req, res) => {
    try {
        const { name, calories, image, macros, date, user_id } = req.body;
        const foodId = uuidv4();

        // Lấy User ID từ Cognito JWT Token do API Gateway truyền xuống
        const requestContext = req.requestContext || {};
        const authorizer = requestContext.authorizer || {};
        const jwt = authorizer.jwt || {};
        const claims = jwt.claims || {};
        const cognitoUserId = claims.sub || user_id || "anonymous";

        const putCommand = new PutCommand({
            TableName: FOODS_TABLE,
            Item: {
                food_id: foodId,
                user_id: cognitoUserId, // Phân quyền dữ liệu theo User
                name,
                calories,
                image,
                macros,
                date: date || new Date().toISOString()
            }
        });

        await docClient.send(putCommand);
        res.status(201).json({ success: true, food_id: foodId, user_id: cognitoUserId });
    } catch (err) {
        console.error("Lỗi DynamoDB Put:", err);
        res.status(500).json({ error: "Could not create food item" });
    }
});

// 3. API: Lấy danh sách thức ăn
app.get("/api/foods", async (req, res) => {
    try {
        const scanCommand = new ScanCommand({
            TableName: FOODS_TABLE
        });

        const { Items } = await docClient.send(scanCommand);
        res.json(Items);
    } catch (err) {
        console.error("Lỗi DynamoDB Scan:", err);
        res.status(500).json({ error: "Could not fetch foods" });
    }
});

// 4. API: Proxy Gemini AI - Phân tích ảnh món ăn
app.post("/api/gemini/analyze-image", async (req, res) => {
    try {
        const { imageBase64 } = req.body;
        if (!imageBase64) return res.status(400).json({ error: "Missing imageBase64" });

        const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

        let cleanBase64 = imageBase64;
        if (imageBase64.includes("base64,")) {
            cleanBase64 = imageBase64.split("base64,")[1];
        }

        const prompt = `Phân tích hình ảnh món ăn này và cung cấp thông tin dinh dưỡng chi tiết dưới định dạng JSON.
Chỉ trả về DUY NHẤT một đối tượng JSON hợp lệ với cấu trúc chính xác sau:
{
    "name": "Tên món ăn bằng tiếng Việt",
    "calories": tổng lượng calo ước tính,
    "protein": số gram protein,
    "carbs": số gram carbohydrates,
    "fat": số gram chất béo,
    "servingSize": "mô tả kích thước",
    "ingredients": [
        { "name": "tên nguyên liệu 1", "amount": "150g" }
    ]
}`;

        const result = await model.generateContent([
            prompt,
            { inlineData: { data: cleanBase64, mimeType: "image/jpeg" } },
        ]);
        const response = await result.response;
        const text = response.text();
        const cleanedText = text.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();

        // Đảm bảo trả về đúng format FoodAnalysisResult
        res.json({ success: true, data: JSON.parse(cleanedText) });
    } catch (err) {
        console.error("Lỗi Gemini Image:", err);
        res.status(500).json({ success: false, error: "Failed to analyze image" });
    }
});

// 5. API: Proxy Gemini AI - Coach
app.post("/api/gemini/coach", async (req, res) => {
    try {
        const { userMessage, chatHistory, contextString } = req.body;
        if (!userMessage) return res.status(400).json({ success: false, error: "Missing userMessage" });

        const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

        const AI_COACH_SYSTEM_PROMPT = `You are an AI Nutrition Coach integrated inside a nutrition and health application named NutriTrack.
Your role is to act as a professional nutrition advisor that helps users improve their eating habits and health.

CORE RESPONSIBILITIES
You can:
• Answer nutrition and healthy eating questions
• Recommend healthy meals
• Suggest recipes based on available ingredients
• Analyze the user's nutrition data

ADVICE STYLE
You should respond as a friendly and knowledgeable nutrition expert.
Responses should be: Clear, Helpful, Evidence-based, Practical for everyday eating.

LANGUAGE RULE
Respond in the SAME LANGUAGE used by the user. If they speak Vietnamese, respond in Vietnamese.

DATA CONTEXT (Provided by application)
When the application provides context about user's fridge, meals, or profile, use it to personalize your advice.

OUTPUT FORMAT
If you want to suggest a specific food item that the app can display as a card, include a JSON block at the end of your message in this format:
[FOOD_CARD: {"name": "Món ăn", "description": "Mô tả ngắn", "calories": 450, "emoji": "🍱"}]`;

        const fullPrompt = `${AI_COACH_SYSTEM_PROMPT}\n\nUSER CONTEXT:\n${contextString ? JSON.stringify(contextString) : ""}\n\nNow, respond to the user's message.`;

        const chat = model.startChat({
            history: chatHistory || [],
            generationConfig: {
                maxOutputTokens: 1000,
            },
        });

        const result = await chat.sendMessage(fullPrompt + "\n\nUser: " + userMessage);
        const response = await result.response;
        const text = response.text();

        let foodSuggestion = undefined;
        const cardMatch = text.match(/\[FOOD_CARD: (\{.*?\})\]/);
        if (cardMatch) {
            try {
                foodSuggestion = JSON.parse(cardMatch[1]);
            } catch (e) {
                console.error('Failed to parse food card JSON', e);
            }
        }

        const cleanedText = text.replace(/\[FOOD_CARD: \{.*?\}\]/g, '').trim();

        res.json({
            success: true,
            text: cleanedText,
            foodSuggestion,
        });
    } catch (err) {
        console.error("Lỗi Gemini Coach:", err);
        res.status(500).json({ success: false, error: "Failed to get coach response" });
    }
});

// Bắt các đường dẫn không hỗ trợ
app.use((req, res, next) => {
    return res.status(404).json({
        error: "Not Found",
    });
});

// Bọc toàn bộ Express App thành AWS Lambda Handler bằng serverless-http
module.exports.handler = serverless(app);
